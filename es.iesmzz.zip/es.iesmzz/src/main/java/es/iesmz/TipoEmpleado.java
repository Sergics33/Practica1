package es.iesmz;

public enum TipoEmpleado {
    vendedor, encarregat ;
}
